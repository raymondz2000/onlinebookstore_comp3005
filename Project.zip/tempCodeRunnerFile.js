
// app.get("/",(req,res,next)=>{
//     req.app.db.collection("books").find().toArray((err, results) => {
//         const allmovie = results;
//         res.status(200).send(pug.renderFile("./public/pug/homepage.pug",{allmovies: allmovie}));
//     });
//     const sql = 'SELECT * FROM items ORDER BY id ASC';
//     pool.query(sql, (error, results) => {
//         if (error) {
//             throw error;
//         }
//         res.render("allItemInfo.ejs", {todoDbList: results.rows})
//     })
// })