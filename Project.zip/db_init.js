
const {Client} = require('pg');

//database name

const client = new Client({
	user:'postgres',
	host: 'localhost',
	database:'bk',
	password:'zhuyanhui',
	port: '5432',

});
client.connect();
const fs = require("fs");
// export default client;

//init db
var sql = fs.readFileSync('init_database.sql').toString();

    client.query(sql, function(err, result){
        
        if(err){
            console.log('error: ', err);
            process.exit(1);
        }
		console.log(res);

		client.end();
		process.exit(0);

});
 

//search
// client.query('select *from Bookstore.book', (err, res) => {
// 	console.log(res.rows);
// 	client.end();
//   });
//insert
 
// client.query("INSERT INTO Bookstore.book VALUES('0743212332', 'call', 'ray', 'King', 'Thriller', 'Scribner', '123', 32, 6,0)", (err, res) => {
// 	console.log(err);
// 	client.end();
//   });

 //delete
//   client.query("delete from Bookstore.book where Bookstore.book.book_name = 'call'", (err, res) => {
// 	console.log(err);
// 	client.end();
//   });






















// const Movie = require("./Model/movieModel");
// const User = require("./Model/userModel");
// const Person = require("./Model/personModel"); 




// mongoose.connect('mongodb://localhost/project', {useNewUrlParser: true});
// let db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function() {
// 	mongoose.connection.db.dropDatabase(function(err, result){
// 		if(err){
// 			console.log("Error dropping database:");
// 			console.log(err);
// 			return;
// 		}
// 		console.log("Dropped project database. Starting re-creation.");


//         //!moviedata
// 		let movies = JSON.parse(fs.readFileSync("./initialize_data/movie.json"));
//         let completedMovie = 0;
//         let movieid=0;
// 		movies.forEach(movie => {
//             movie.review=[];
//             movie.movieid= movieid+=1;
//             let movielist = new Movie(movie);
// 			movielist.save(function(err,result){
// 				if(err) throw err;
// 				completedMovie ++;
// 				if(completedMovie  >= movies.length){
// 					console.log("All movies aved.");
// 				}
// 			})
// 		});
//     //!usersdata
//         let users = JSON.parse(fs.readFileSync("./initialize_data/user.json"));
//         let completedUser = 0;
//         let userid=0;
// 		users.forEach(user => {
//             user.userid = userid++;
//             let userlist = new User(user);
// 			userlist.save(function(err,result){
// 				if(err) throw err;
// 				completedUser ++;
// 				if(completedUser  >= users.length){
// 					console.log("All user saved.");
// 				}
// 			})
// 		});
        
//         //!persondata
//         let persons = JSON.parse(fs.readFileSync("./initialize_data/ppfollow.json"));
//         let completedPerson = 0;
//         let personid=0;
// 		persons.forEach(person => {
//             person.personid = personid++;
//             let personlist = new Person(person);
// 			personlist.save(function(err,result){
// 				if(err) throw err;
// 				completedPerson ++;
// 				if(completedPerson  >= persons.length){
// 					console.log("All person saved.");
                    
//                     process.exit();
// 				}
// 			})
// 		});

        
        
// 	});
    
// });