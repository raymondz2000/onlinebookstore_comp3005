
//TODO server
const express = require('express');
const pug = require('pug');
const path = require('path');
var fs = require('fs');

var bodyParser = require("body-parser");
const session = require('express-session')
let app = express();

//Database variables
//
const Pool = require('pg').Pool

const pool = new Pool({
    user:'postgres',
	host: 'localhost',
	database:'bk',
	password:'zhuyanhui',
	port: '5432',
})

 

// Use the session middleware
app.use(session({ secret: 'some secret here'}))



 //set the home directly
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({extended: true}));



//homepage
app.get('/', (request, response) => {
    pool.query('select * from Bookstore.book', (err, res) =>{
        if(err) throw err;
        const allbooks = res.rows;
        
       response.status(200).send(pug.renderFile("./public/pug/homepage.pug",{allbooks:allbooks}));
    })
})
//admin homepage
app.get('/admin', (request, response) => {
    if(!request.session.loggedin){
        response.redirect('/html/Signinadmin.html');
        return;
    }
    pool.query('select * from Bookstore.book', (err, res) =>{
        if(err) throw err;
        const allbooks = res.rows;
        
       response.status(200).send(pug.renderFile("./public/pug/homepageadmin.pug",{allbooks:allbooks}));
    })
})

//browse all book
app.get('/allbooks', (request, response) => {
    pool.query('select * from Bookstore.book', (err, res) =>{
        if(err) throw err;
        const allbooks = res.rows;
         
       response.status(200).send(pug.renderFile("./public/pug/booklist.pug",{allbooks:allbooks}));
    })
})

//show book
app.get("/book/:book_name",(request, response)=>{
    let value = request.params.book_name;
	 
	console.log("Finding book by name: " + value);
	try{
		//oid = new ObjectId(value);
       
	}catch(err){
		res.status(404).send("book " + value + " does not exist.");
		return;
	}
        const sql = "select * from Bookstore.book where book_name = $1"
        const values=[value]
        
		pool.query(sql,values,(err, res) =>{
			if(err) throw err;
			const books = res.rows;
			console.log(books)
		   response.status(200).send(pug.renderFile("./public/pug/book.pug",{allbooks:books[0]}));
		})
})
//admin show book
app.get("/adminbook/:book_name",(request, response)=>{
    let value = request.params.book_name;
	 
	console.log("Finding book by name: " + value);
	try{
		//oid = new ObjectId(value);
       
	}catch(err){
		res.status(404).send("book " + value + " does not exist.");
		return;
	}
        const sql = "select * from Bookstore.book where book_name = $1"
        const values=[value]
        
		pool.query(sql,values,(err, res) =>{
			if(err) throw err;
			const books = res.rows;
			console.log(books)
		   response.status(200).send(pug.renderFile("./public/pug/adminbook.pug",{allbooks:books[0]}));
		})
})
//delete book
app.post("/adminbook/:book_isbn",(request, response)=>{
//delete
const sql8 = "delete from bookstore.book WHERE book_isbn = $1"
const values8=[request.params.book_isbn] 
console.log(values8)
pool.query(sql8,values8,(err2, res2) =>{

    if(err2) throw err2;
    console.log("delete success")
})
response.redirect('/admin');
})

//add book to shopping cart
app.post("/book/:book_name/:book_isbn/:author_first_name/:author_last_name/:genre",(request, response)=>{

    if(!request.session.loggedin){
        response.redirect('/html/Signin.html');
        return;
    }
    
    let value = request.params.book_name;
	 
	console.log("post Finding book by name: " +   request.params.book_isbn);
	try{
		//oid = new ObjectId(value);
       
	}catch(err){
		res.status(404).send("book " + value + " does not exist.");
		return;
	}
    //update book
    const sql4 = "UPDATE bookstore.book SET selected_number = 1 WHERE book_isbn = $1"
    const values4=[request.params.book_isbn] 
    console.log(values4)
    pool.query(sql4,values4,(err2, res2) =>{

        if(err2) throw err2;
     
    })

    const sql = "select * from Bookstore.customer where cu_user_name = $1"
    const values=[request.session.username] 
    pool.query(sql,values,(err, res) =>{
       
        const sql3 = "select * from bookstore.cart where book_isbn = $1";
        const values3=[request.params.book_isbn]
       

        console.log(res.rows[0].customer_id)
        
        pool.query(sql3,values3,(err2, res2) =>{

        if(err2) throw err2;
           
           if(res2.rows.length==0){
            const sql2 = "insert into bookstore.cart values ($1, $2, $3, $4,$5,$6, 5)"
            console.log("add")
            const values=[res.rows[0].customer_id,request.params.book_isbn,request.params.book_name,request.params.author_first_name,request.params.author_last_name,request.params.genre]
            pool.query(sql2,values,(err2, res2) =>{

                if(err2) throw err2;
    
                })
        
 
        }
    })
        
           
    })



        // const sql = "select * from Bookstore.book where book_name = $1"
        // const values=[value]
        
		// pool.query(sql,values,(err, res) =>{
		// 	if(err) throw err;
		// 	const books = res.rows;
		// 	console.log(books)
		//    response.status(200).send(pug.renderFile("./public/pug/book.pug",{allbooks:books[0]}));
		// })
})


//customer signin and adminsignin
app.post("/signin",(req,res,next)=>{
    //res.status(200).sendFile(path.join(__dirname+'/public/html/Signin.html'));
    if(req.session.loggedin){
		res.status(200).send("Already logged in, pleace check back to profile page");
         
		return;
	}
 
    console.log("Logging in with credentials:");
    console.log(req.body);
    console.log("Username: " + req.body.username);
    console.log("Password: " + req.body.password);


    const sql = "select * from Bookstore.customer where cu_user_name = $1 AND cu_password = $2";
    const values=[req.body.username,req.body.password];

  
    pool.query(sql,values,(err, result) =>{
    const userdata = result.rows;
    userdata.forEach(userdata=>{
         
        if((userdata.cu_user_name === req.body.username) && (userdata.cu_password == req.body.password)){
            req.session.loggedin = true;
            req.session.username = req.body.username;
            res.status(200)
            res.redirect("/userprofile/");
            next();
            //res.status(200).send("Logged in");
        }
      
    })
     if(!req.session.loggedin){
      //  res.status(401)
        res.redirect("/html/error.html");
     }
 })
})
app.post("/adminsignin",(req,res,next)=>{
    //res.status(200).sendFile(path.join(__dirname+'/public/html/Signin.html'));
    if(req.session.loggedin){
		res.status(200).send("Already logged in, pleace check back to profile page");
         
		return;
	}
 
    console.log("Logging in with admin credentials:");
    console.log(req.body);
    console.log("Username: " + req.body.username);
    console.log("Password: " + req.body.password);

    
    const sql = "select * from Bookstore.superuser where su_name = $1 AND su_password = $2";
    const values=[req.body.username,req.body.password];  
    pool.query(sql,values,(err, result) =>{
    const userdata = result.rows;
    userdata.forEach(userdata=>{
         
        if((userdata.su_name === req.body.username) && (userdata.su_password == req.body.password)){
            req.session.loggedin = true;
            req.session.username = req.body.username;
            res.status(200)
            res.redirect("/admin");
            next();
            //res.status(200).send("Logged in");
        }
      
    })
     if(!req.session.loggedin){
      //  res.status(401)
        res.redirect("/html/error.html");
     }
 })
})

//user signin/and profile
app.get("/userprofile/",(request, response)=>{
    if(!request.session.loggedin){
        response.redirect('/html/Signin.html');
        return;
    }
    

	console.log("find user by name: " + request.session.username);
	try{
		//oid = new ObjectId(value);
       
	}catch(err){
		res.status(404).send("customer " + value + " does not exist.");
		return;
	}
        const sql = "select * from Bookstore.customer where cu_user_name = $1"
        const values=[request.session.username]
         
		pool.query(sql,values,(err, res) =>{
            const sql2 = "select * from bookstore.cart where customer_id = $1"
            const values=[res.rows[0].customer_id]
             
            pool.query(sql2,values,(err2, res2) =>{

			if(err2) throw err;
			const carts = res2.rows;
			 
		    response.status(200).send(pug.renderFile("./public/pug/userprofile.pug",{carts:carts,LogininUser:request.session.username}));

            })
		})
})
app.get("/userprofile/signin",(request, response)=>{
    response.redirect('/html/Signin.html');
})
app.get("/adminsignin",(request, response)=>{
    response.redirect('/html/Signinadmin.html');
})


//sign up user and customer
app.post("/signup",(req,res,next)=>{
    console.log("signip")
    username = req.body.usernames
    password = req.body.password
    email = req.body.mailbox
    
    const sql = "INSERT INTO bookstore.customer VALUES('100',$1,$2);"
    const values=[username,password]
    pool.query(sql,values,(err2, res2) =>{

        if(err2) throw err;

    })
    console.log(username);
    console.log(password);
    res.redirect('/userprofile/signin');
})

app.post("/adminsignup",(req,res,next)=>{
    console.log("signip")
    username = req.body.usernames
    password = req.body.password
    email = req.body.mailbox
    
    const sql = "INSERT INTO bookstore.superuser VALUES('100',$1,$2);"
    const values=[username,password]
    pool.query(sql,values,(err2, res2) =>{

        if(err2) throw err;

    })
    console.log(username);
    console.log(password);
    res.redirect('/adminsignin');
})



//search by specific attribute or global search
app.get("/search",(req,res,next)=>{
    res.status(200).send(pug.renderFile("./public/pug/search.pug"));
})
app.post("/searchResults/search",(req,response,next)=>{
    const sql10 = 'select * from Bookstore.book where book_isbn = $1 AND book_name = $2 AND author_first_name = $3'
    const value10=[req.body.ISBN,req.body.NAME,req.body.afn]
    console.log(value10)
    pool.query(sql10,value10, (err, res) =>{
        if(err) throw err;
        const allbooks = res.rows;
        response.status(200).send(pug.renderFile("./public/pug/searchResult.pug",{allbooks:allbooks}));
    })
   
     
})
app.get("/searchResults",(req,response,next)=>{
    const sql11 = 'select * from Bookstore.book where book_isbn = $1 OR book_name = $2 OR author_first_name = $3'
    const value11=[req.body.ISBN,req.body.NAME,req.body.afn]
    pool.query(sql11,value11, (err, res) =>{
        if(err) throw err;
        const allbooks = res.rows;
        response.status(200).send(pug.renderFile("./public/pug/searchResult.pug",{allbooks:allbooks}));
    })
   
     
})
//---------------------------------------------------

//contribute and update db (add)
app.get("/contribute",(req,res,next)=>{
    if(!req.session.loggedin){
        res.redirect('/adminsignin');
        return;
    }
    res.status(200).send(pug.renderFile("./public/pug/contribute.pug"));
})

//add books
app.post("/contribute/add/",(req,res,next)=>{

const sql6 = "INSERT INTO bookstore.book VALUES($1,$2,$3,$4,$5,$6,$7,$8,0);"
const values = [req.body.isbn,req.body.bookname,req.body.authorfirstname,req.body.authorlastname,req.body.genre,req.body.book_publisher,req.body.sp,req.body.bp]
console.log(values)
pool.query(sql6,values, (err, res) =>{
    if(err) throw err;
     
    console.log("success!");
    
})
    res.redirect('/admin');
 

})
 
//connect data base
app.listen(3000, () => {
    console.log("Listening on port 3000.")
})