create schema bookstore;

create table bookstore.customer
	(customer_id	varchar(10),
	cu_user_name	varchar(20) not null,
	cu_password		varchar(20) not null,
	primary key (customer_id)
);

INSERT INTO bookstore.customer VALUES('001','johnsmith','1111');
INSERT INTO bookstore.customer VALUES('002','frankwong','2222');
INSERT INTO bookstore.customer VALUES('003','alicezela','3333');
INSERT INTO bookstore.customer VALUES('004','jennywall','4444');
INSERT INTO bookstore.customer VALUES('005','rameynara','5555');

create table bookstore.book
	(book_isbn				varchar(50),
	 book_name				varchar(50),
	 author_first_name		varchar(50),
	 author_last_name		varchar(50),
	 genre					varchar(50),
	 book_publisher			varchar(50),
	 book_pages				numeric(10,0),
	 book_selling_price		numeric(10,2),
	 book_basic_price		numeric(10,2),
	 selected_number		numeric(10,0),
	 
	 primary key (book_isbn)
);

INSERT INTO bookstore.book VALUES('0691065322','Cape Cod','Henry','Thoreau','Fiction','Princeton University Press','441',19.9, 5.5, 0);
INSERT INTO bookstore.book VALUES('0385539258','A Little Life','Hanya','Yanagihara','Fiction','Doubleday','742',70, 20, 0);
INSERT INTO bookstore.book VALUES('0525945563','Red Dragon','Thomas','Harris','Classic','Dutton', '384',30.5, 7, 0);
INSERT INTO bookstore.book VALUES('0373022506','Ring in a Teacup','Betty','Neels','Kids','Mills and Boon','187', 25.5, 10, 0);
INSERT INTO bookstore.book VALUES('0743292332', 'Cell', 'Stephen', 'King', 'Thriller', 'Scribner', '355', 32, 6,0);

create table bookstore.the_date
	(date_id		numeric(10,0),
	 date_year		numeric(10,0),
	 date_month		numeric(10,0),
	 date_day		numeric(10,0),
	 primary key (date_id)
);

insert into bookstore.the_date values (1, 2015, 4, 14);
insert into bookstore.the_date values (2, 2018, 6, 20);
insert into bookstore.the_date values (3, 2019, 5, 20);
insert into bookstore.the_date values (4, 2020, 11, 5);
insert into bookstore.the_date values (5, 2021, 12, 24);

create table bookstore.order
	(order_number	numeric(10, 0),
	 total_price	numeric(10, 0),
	 date_id		numeric(10, 0),
	primary key (order_number),
	foreign key (date_id) references bookstore.the_date(date_id)
);
--1st order, 'Cape Cod'
--2nd order, 'Cape Cod + Ring in a Teacup'
--3rd order, 'Cell'
--4th order, 'Red Dragon'
--5th order, 'Cell + Red Dragon'
insert into bookstore.order values (1, 19.9, 1);
insert into bookstore.order values (2, 45.4, 2);
insert into bookstore.order values (3, 32, 3);
insert into bookstore.order values (4, 30.5, 4);
insert into bookstore.order values (5, 62.5, 5);


create table bookstore.cart
	(customer_id				varchar(10),
	 book_isbn				varchar(50),
	 book_name				varchar(50),
	 author_first_name			varchar(50),
	 author_last_name			varchar(50),
	 genre					varchar(50),
	 order_number			numeric(10, 0),
	 primary key (customer_id, book_isbn, order_number),
	 foreign key (customer_id) references bookstore.customer(customer_id) on delete cascade,
	 foreign key (book_isbn) references bookstore.book(book_isbn) on delete cascade,
	 foreign key (order_number) references bookstore.order(order_number)
);

insert into bookstore.cart values ('001', '0743292332', 'Cell', 'Stephen', 'King', 'Thriller', 5);
insert into bookstore.cart values ('001', '0525945563', 'Red Dragon', 'Thomas','Harris','Classic', 5);



create table bookstore.warehouse
	(book_isbn			varchar(50),
	 inventory_book		numeric(10,0),
	 primary key (book_isbn),
	 foreign key (book_isbn) references bookstore.book (book_isbn) on delete cascade
);
--ten book each, testing purpose
insert into bookstore.warehouse values ('0691065322', 10);
insert into bookstore.warehouse values ('0385539258', 10);
insert into bookstore.warehouse values ('0525945563', 10);
insert into bookstore.warehouse values ('0373022506', 10);
insert into bookstore.warehouse values ('0743292332', 10);


create table bookstore.bank
	(bank_account		varchar(50),
	 amount				numeric(10,2),
	 primary key (bank_account)
);

insert into bookstore.bank values ('11111', 0);
insert into bookstore.bank values ('22222', 0);
insert into bookstore.bank values ('33333', 0);
insert into bookstore.bank values ('44444', 0);
insert into bookstore.bank values ('55555', 0);

create table bookstore.publisher
	(publisher_name		varchar(50),
	 publisher_email	varchar(50),
	 phone_number		varchar(50),
	 bank_account 		varchar(50),
	 primary key (publisher_name),
	 foreign key (bank_account) references bookstore.bank (bank_account) on update cascade
);

insert into bookstore.publisher values ('Princeton University Press', 'princeton@xxx.com', '7802673667', '11111');
insert into bookstore.publisher values ('Doubleday', 'double@xxx.com', '5195846225', '22222');
insert into bookstore.publisher values ('Dutton', 'dutton@xxx.com', '2046638457', '33333');
insert into bookstore.publisher values ('Mills and Boon', 'mills@xxx.com', '7095619616', '44444');
insert into bookstore.publisher values ('Scribner', 'scribner@xxx.com', '9022329538', '55555');

create table bookstore.superuser
	(su_id				numeric(10,0),
	 su_name			varchar(50),
	 su_password		varchar(50),
	 primary key (su_id)
);

insert into bookstore.superuser values (1, 'manager', 'password');

create table bookstore.restock
	(publisher_name		varchar(50),
	 book_isbn			varchar(50),
	 su_id				numeric(10,0),
	 primary key (publisher_name, book_isbn, su_id),
	 foreign key (publisher_name) references bookstore.publisher (publisher_name),
	 foreign key (book_isbn) references bookstore.warehouse (book_isbn),
	 foreign key (su_id) references bookstore.superuser (su_id) on delete cascade
);


create table bookstore.address
	(address_id		numeric(10, 0),
	 street_number	varchar(50),
	 apt_number		varchar(50),
	 zip			varchar(50),
	 city 			varchar(50),
	 addr_state		varchar(50),
	 country 		varchar(50),
	 primary key (address_id)
);

insert into bookstore.address values (1, '380 Heather St.', '210', '34231', 'Sarasota', 'FL', 'USA');
insert into bookstore.address values (2, '7881 Main Rd.', '1855', '27330', 'Sanford', 'NC', 'USA');
insert into bookstore.address values (3, '55 Beechwood Drive', '590', '60048', 'Libertyville', 'IL', 'USA');
insert into bookstore.address values (4, '2 Harvey St.', '002', '21075', 'Elkridge', 'MD', 'USA');
insert into bookstore.address values (5, '9654 Ryan Dr.', '500', '33139', 'Miami Beach', 'FL', 'USA');


create table bookstore.publisher_addr
	(address_id			numeric(10, 0),
	 publisher_name		varchar(50),
	 
	 primary key (address_id, publisher_name),
	 foreign key (address_id) references bookstore.address(address_id),
	 foreign key (publisher_name) references bookstore.publisher(publisher_name) on delete cascade
);

insert into bookstore.publisher_addr values (1, 'Doubleday');
insert into bookstore.publisher_addr values (2, 'Mills and Boon');

	
create table bookstore.shipping_info
	(ship_id		numeric(10, 0),
	 card_number 	varchar(50),
	 first_name		varchar(50),
	 last_name		varchar(50),
	 phone_number	varchar(50),
	 primary key (ship_id)
);

insert into bookstore.shipping_info values (1, 'John', 'Doe', '6132224152');
insert into bookstore.shipping_info values (2, 'Annie', 'Who', '5230259482');

create table bookstore.ship_addr
	(ship_id		numeric(10, 0),
	 address_id		numeric(10, 0),
	 primary key (ship_id, address_id),
	 foreign key (ship_id) references bookstore.shipping_info (ship_id),
	 foreign key (address_id) references bookstore.address (address_id)
);

insert into bookstore.ship_addr values (1, 4);
insert into bookstore.ship_addr values (2, 5);

create table bookstore.order_ship
	(order_number		numeric(10, 0),
	 ship_id			numeric(10, 0),
	 primary key (order_number, ship_id),
	 foreign key (order_number) references bookstore.order (order_number),
	 foreign key (ship_id) references bookstore.shipping_info (ship_id)
);

insert into bookstore.order_ship values (1, 1);
insert into bookstore.order_ship values (2, 2);

create table bookstore.billing_info
	(bill_id		numeric(10,0),
	 card_number 	varchar(50),
	 first_name		varchar(50),
	 last_name		varchar(50),
	 primary key (bill_id)
);

insert into bookstore.billing_info values (1, 'creditcard999', 'John', 'Doe');
insert into bookstore.billing_info values (2, 'creditcard111', 'Annie', 'Who');

create table bookstore.bill_addr
	(bill_id		numeric(10,0),
	 address_id		numeric(10,0),
	 primary key (bill_id, address_id),
	 foreign key (bill_id) references bookstore.billing_info (bill_id),
	 foreign key (address_id) references bookstore.address (address_id)
);

insert into bookstore.bill_addr values (1, 4);
insert into bookstore.bill_addr values (2, 5);


create table bookstore.order_bill
	(order_number		numeric(10,0),
	 bill_id		numeric(10,0),
	 primary key (order_number, bill_id),
	 foreign key (order_number) references bookstore.order (order_number),
	 foreign key (bill_id) references bookstore.billing_info (bill_id)
);

insert into bookstore.order_bill values (1, 1);
insert into bookstore.order_bill values (2, 2);


create table bookstore.sale_per_first_name
	(author_first_name		varchar(50),
	 sales					numeric(10,2),
	 expenditures			numeric(10,2),
	 primary key (author_first_name)
);

insert into bookstore.sale_per_first_name values ('Henry', 39.8, 11);
insert into bookstore.sale_per_first_name values ('Stephen', 64, 12);
insert into bookstore.sale_per_first_name values ('Betty', 25.2, 10);
insert into bookstore.sale_per_first_name values('Thomas', 61, 14);

create table bookstore.sale_per_last_name
	(author_last_name		varchar(50),
	 sales					numeric(10,2),
	 expenditures			numeric(10,2),
	 primary key (author_last_name)
);

insert into bookstore.sale_per_last_name values ('Thoreau', 39.8, 11);
insert into bookstore.sale_per_last_name values ('King', 64, 12);
insert into bookstore.sale_per_last_name values ('Neels', 25.2, 10);
insert into bookstore.sale_per_last_name values('Harris', 61, 14);

create table bookstore.sale_per_genre
	(genre					varchar(50),
	 sales					numeric(10,2),
	 expenditures			numeric(10,2),
	 primary key (genre)
);

insert into bookstore.sale_per_genre values ('Kids', 25.5, 10);
insert into bookstore.sale_per_genre values ('Fiction', 39.8, 11);
insert into bookstore.sale_per_genre values ('Classic', 61, 14);
insert into bookstore.sale_per_genre values ('Thriller', 64, 12);


create table bookstore.sales_report
	(order_number					numeric(10,0),
	 su_id							numeric(10,0),
	 author_first_name				varchar(50),
	 author_last_name				varchar(50),
	 genre							varchar(50),
	 primary key (order_number, su_id, author_first_name, author_last_name, genre),
	 foreign key (order_number) references bookstore.order (order_number),
	 foreign key (su_id) references bookstore.superuser (su_id),
	 foreign key (author_first_name) references bookstore.sale_per_first_name (author_first_name) on update cascade,
	 foreign key (author_last_name) references bookstore.sale_per_last_name (author_last_name)on update cascade,
	 foreign key (genre) references bookstore.sale_per_genre (genre) on update cascade
);

insert into bookstore.sales_report values (1, 1, 'Henry', 'Thoreau', 'Fiction');
insert into bookstore.sales_report values (2, 1, 'Henry', 'Thoreau', 'Fiction');
insert into bookstore.sales_report values (2, 1, 'Betty', 'Neels', 'Kids');
insert into bookstore.sales_report values (3, 1, 'Stephen', 'King', 'Thriller');
insert into bookstore.sales_report values (4, 1, 'Thomas', 'Harris', 'Classic');
insert into bookstore.sales_report values (5, 1, 'Stephen', 'King', 'Thriller');
insert into bookstore.sales_report values (5, 1, 'Thomas', 'Harris', 'Classic');
