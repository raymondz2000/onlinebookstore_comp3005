'select * from Bookstore.book'

//select specific book with name
"select * from Bookstore.book where book_name = $1"

//select specific book with isbn
"delete from bookstore.book WHERE book_isbn = $1"

//update number of selected for specific book
"UPDATE bookstore.book SET selected_number = 1 WHERE book_isbn = $1"


//check specific customer
"select * from Bookstore.customer where cu_user_name = $1"

//insert book to cart
 "insert into bookstore.cart values ($1, $2, $3, $4,$5,$6, 5)"

//query specific user match username and password
"select * from Bookstore.customer where cu_user_name = $1 AND cu_password = $2";

//query specific supervisor match username and password
"select * from Bookstore.superuser where su_name = $1 AND su_password = $2";

//query customer id
"select * from bookstore.cart where customer_id = $1"

//register customer
"INSERT INTO bookstore.customer VALUES('100',$1,$2);"

//register supervisor
"INSERT INTO bookstore.superuser VALUES('100',$1,$2);"

//search book
'select * from Bookstore.book where book_isbn = $1 AND book_name = $2 AND author_first_name = $3'
'select * from Bookstore.book where book_isbn = $1 OR book_name = $2 OR author_first_name = $3'

//add books
"INSERT INTO bookstore.book VALUES($1,$2,$3,$4,$5,$6,$7,$8,0);"